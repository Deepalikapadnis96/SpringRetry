package com.ndps.spring.schedular.api.taskschedular;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.PeriodicTrigger;

@Configuration
@ComponentScan(basePackages = "com.ndps.spring.schedular.api.taskscheduler", basePackageClasses = {
		ThreadPoolTaskSchedulerex.class })
public class ThreadPoolTaskSchedulerConfig {

	// The configured bean threadPoolTaskScheduler can execute tasks asynchronously
	// based on the configured pool size of 5.

	// Note that all ThreadPoolTaskScheduler related thread names will be prefixed
	// with ThreadPoolTaskScheduler.

	@Bean
	public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(5);//how many task can b execute concurrently
		threadPoolTaskScheduler.setThreadNamePrefix("ThreadPoolTaskScheduler ");
		return threadPoolTaskScheduler;
	}

	// In this case, the RunnableTask will be executed at the 10th second of every
	// minute.
	@Bean
	public CronTrigger cronTrigger() {
		return new CronTrigger("10 * * * * ?");//will run after 10 sec (12:05:10-->>12:06:10)
	}
	
	// In this case, the RunnableTask will be executed at the 10th second of every
	// minute.
	@Bean
	public PeriodicTrigger periodicTrigger() {
		return new PeriodicTrigger(10000, TimeUnit.MILLISECONDS);//will start after 10mill sec
	}

	// We can also configure PeriodicTrigger to be initialized at a fixed rate,
	// rather than a fixed delay. Furthermore, we can set an initial delay for the
	// first scheduled task by a given milliseconds
	@Bean
	public PeriodicTrigger periodicFixedDelayTrigger() {
		PeriodicTrigger periodicTrigger = new PeriodicTrigger(2000, TimeUnit.MINUTES);
		periodicTrigger.setFixedRate(true);
		periodicTrigger.setInitialDelay(2000);
		return periodicTrigger;
	}
	// We used the setFixedRate method to schedule the task at a fixed rate, rather
	// than with a fixed delay. Then we used the setInitialDelay method to set an
	// initial delay for the first runnable task to run.
	
	 
}
