package com.ndps.spring.schedular.api.scheduling;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ndps.spring.schedular.api.async.AsyncComponent;

import lombok.extern.java.Log;
@Component("scheduledAnnotationEx")
@Log
public class ScheduledAnnotationEx {

	
	@Autowired
	private AsyncComponent asyncComp;
	
	@Scheduled(fixedDelay = 2000)
    public void scheduleFixedDelayTask() throws Exception {
		//asyncComp.asyncMethodWithVoidReturnType();//(2+1=3)
		//asyncComp.asyncMethodWithReturnType();//(2+5=7)

		asyncComp.asyncMethodWithConfiguredExecutor();
		//asyncComp.asyncMethodWithExceptions();
    }

    @Scheduled(fixedDelayString = "${fixedDelay.in.milliseconds}")//(hr.min.sec)
    public void scheduleFixedDelayTaskUsingExpression() {
    	// log.info(String.format("Scheduling Fixed delay task in milli sec: %s ", new Date().getTime()));//difference of 16ms
    }
  
    @Scheduled(fixedDelay = 4000, initialDelay = 5000)
    public void scheduleFixedDelayWithInitialDelayTask() {
    	//log.info(String.format("Fixed delay task with one second initial delay: %s " , new Date()));
    }
   
    @Scheduled(fixedRate = 2000)
    public void scheduleFixedRateTask() {
    	//log.info(String.format("Fixed rate task:%s " , new Date()));
    }
  
    @Scheduled(fixedRateString = "${fixedRate.in.milliseconds}")
    public void scheduleFixedRateTaskUsingExpression() {
    	//log.info(String.format("Fixed rate task: %s " , new Date().getTime()));//diff of 1007,991
    }

    @Scheduled(fixedDelay = 1000, initialDelay = 1000)
    public void scheduleFixedRateWithInitialDelayTask() {
       // System.out.println("Fixed rate task with one second initial delay - "  + new Date());
    }
    /*
    
     // Scheduled task is executed at 10:15 AM on the 15th day of every month
     
    @Scheduled(cron = "0 15 10 15 * ?")
    public void scheduleTaskUsingCronExpression() {
        long now = System.currentTimeMillis() / 1000;
        System.out.println("schedule tasks using cron jobs - " + now + new Date());
    }
 
    @Scheduled(cron = "${cron.expression}")
    public void scheduleTaskUsingExternalizedCronExpression() {
        System.out.println("schedule tasks using externalized cron expressions - " + System.currentTimeMillis() / 1000 + new Date());
    } */

}
