package com.ndps.spring.schedular.api.async;

import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.Future;

@Component
public class AsyncComponent {
	
	
	@Async
	@Bean
	public void asyncMethodWithVoidReturnType() {//24,26,28sec
		System.out.println("Execute method asynchronously 1 " + Thread.currentThread().getName() +new Date());
	}

	@Async
	public Future<String> asyncMethodWithReturnType() {
		System.out.println("Execute method asynchronously 2 " + Thread.currentThread().getName()+new Date());
		try {
			Thread.sleep(5000);
			return new AsyncResult<>("hello world !!!!");
		} catch (final InterruptedException e) {
		}
		return null;
	}

	@Async("threadPoolTaskExecutor")
	public void asyncMethodWithConfiguredExecutor() {
		System.out.println("Execute method asynchronously with configured executor 3 " + Thread.currentThread().getName() + new Date());
	}

	@Async
	public void asyncMethodWithExceptions() throws Exception {
		throw new Exception("Throw message from asynchronous method. 4 " + new Date());
	}
}
