package com.ndps.spring.schedular.api.scheduling;

import java.util.Date;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.java.Log;

@Log
@Component
@EnableAsync //concurrnt execution -this switches spring ability to run @async methods in background thread pool
public class ScheduledFixedRateEx {
	@Async //method to be public
	@Scheduled(fixedRate = 2000)
	public void scheduleFixedRateTaskAsync() throws InterruptedException {
		//System.out.println("Fixed rate task async - " + new Date());
		Thread.sleep(2000);
		
	}
}
