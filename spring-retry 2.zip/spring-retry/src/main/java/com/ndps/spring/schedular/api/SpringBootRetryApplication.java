package com.ndps.spring.schedular.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;


@SpringBootApplication
@EnableScheduling
@Component
@EnableRetry
//@EnableAsyncXj

public class SpringBootRetryApplication {
	Logger log = LoggerFactory.getLogger(SpringBootRetryApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRetryApplication.class, args);
	}
	
	
	//@Scheduled(fixedDelay  = 5000L, initialDelay = 20000L)//will first initial delay i.e it will start after 20000 and fixed delay of 5000L
	//@Scheduled(fixedDelay  = 30000L) //fixed rate it will run after 30-30 sec(30000L) //The task always waits until the previous one is finished
	//@Scheduled(fixedRate   = 2000L) // fixed rate it will run after 2-2 sec(2000L) //if we used fixedRate, the next task won't be invoked until the previous one is done.
	//public void job() {
		//log.info("current time " + new Date());
	//}

}
